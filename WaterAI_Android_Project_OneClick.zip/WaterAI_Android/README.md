# WaterAI Android App

A simple Android chat app branded as WaterAI.

## Build the APK on GitHub — one button

1. Create a GitHub repository and upload this whole project folder.
2. Push it to the `main` branch.
3. Open the repository's **Actions** tab.
4. Select **Build WaterAI APK**.
5. Press **Run workflow**.
6. When the run finishes, open the run and download the **WaterAI-debug-apk** artifact.
7. Extract the downloaded artifact to get `app-debug.apk`.

The workflow builds the real Android APK; renaming a ZIP file is not required.

## Build in Android Studio

1. Open Android Studio.
2. Choose **Open** and select this `WaterAI_Android` folder.
3. Let Gradle sync.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be produced under `app/build/outputs/apk/debug/`.

## Notes

- Application ID: `com.waterai.app`
- Minimum Android version: Android 6.0 (API 23)
- Target Android version: API 35
- The current chat replies are local placeholder responses. No API key is included.
