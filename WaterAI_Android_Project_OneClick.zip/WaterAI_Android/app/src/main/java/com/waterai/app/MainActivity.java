package com.waterai.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    LinearLayout chat;
    EditText input;
    ScrollView scroll;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        chat = findViewById(R.id.chat);
        input = findViewById(R.id.input);
        scroll = findViewById(R.id.scroll);
        findViewById(R.id.send).setOnClickListener(v -> send());
        input.setOnEditorActionListener((v, actionId, e) -> { send(); return true; });
    }

    void send() {
        String text = input.getText().toString().trim();
        if (text.isEmpty()) return;
        addBubble(text, true);
        input.setText("");
        new android.os.Handler().postDelayed(() ->
            addBubble("WaterAI is ready. Connect your AI backend to make responses live.", false), 350);
    }

    void addBubble(String text, boolean user) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(16);
        tv.setTextColor(Color.rgb(20,20,20));
        tv.setPadding(16,12,16,12);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(18);
        bg.setColor(user ? Color.rgb(225,232,255) : Color.rgb(240,241,246));
        tv.setBackground(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2,-2);
        p.gravity = user ? Gravity.END : Gravity.START;
        p.setMargins(0,8,0,8);
        tv.setLayoutParams(p);
        chat.addView(tv);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }
}
